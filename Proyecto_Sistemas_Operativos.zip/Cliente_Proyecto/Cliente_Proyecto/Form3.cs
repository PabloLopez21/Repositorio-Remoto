﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Media;

namespace Cliente_Proyecto
{
    public partial class Form3 : Form
    {
        // Variables
        int nForm;
        string host;
        Socket server;
        string Teinvita;
        int id;
        string Tu;
        int tiempoinvitacion = 15;
        int tiempoiniciopartida = 20;

        //Variables Partida
        string[,] cartasmatriz;
        List<string> cartaslista = new List<string>();
        string ListaEnviada;
        int clickcont;
        string eselturnode;
        SoundPlayer sonidoerror = new SoundPlayer(Application.StartupPath + @"\sonidoerror.wav");
        SoundPlayer sonidoacierto = new SoundPlayer(Application.StartupPath + @"\sonidoacierto.wav");

        int puntos;
        int puntuacionmax;
        string ganador;
        

        int parejasacertadas;

        //Funciones
        public Form3(int nForm, Socket server)
        {
            InitializeComponent();
            this.nForm = nForm;
            this.server = server;
        }

        public void MostrarInvitacion(string mensaje, string usuario)
        {
            string[] nombres = mensaje.Split('-');
            Teinvita = nombres[0];
            id = Convert.ToInt32(nombres[1]);
            Tu = usuario;
            label4.Text = ("Te invita " + nombres[0] + " en la partida con Id: " + nombres[1]);
        }

        public void SoyHost(string host)
        {
            this.host = host;
        }

        public void ActualizaChat(string chat)
        {
            richTextBox1.Text = chat;
        }

        public void ActualizaFormulario() // Método que actualiza visualmente el formulario cuando empieza la partida
        {
            label7.Text = "Tus puntos: " + puntos;
        }

        public void Jugada(string turnode)
        {
            this.eselturnode = turnode;
            label8.Text = "Turno de " + turnode;

            clickcont = 0;
            
            if (turnode == Tu)
            {

                pictureBox18.Enabled = true;
                pictureBox19.Enabled = true;
                pictureBox20.Enabled = true;
                pictureBox21.Enabled = true;
                pictureBox22.Enabled = true;
                pictureBox23.Enabled = true;
                pictureBox24.Enabled = true;
                pictureBox25.Enabled = true;
                pictureBox26.Enabled = true;
                pictureBox27.Enabled = true;
                pictureBox28.Enabled = true;
                pictureBox29.Enabled = true;
                pictureBox30.Enabled = true;
                pictureBox31.Enabled = true;
                pictureBox32.Enabled = true;
                pictureBox33.Enabled = true;

                //pictureBox1.Enabled = true;
                //pictureBox2.Enabled = true;
                //pictureBox3.Enabled = true;
                //pictureBox4.Enabled = true;
                //pictureBox5.Enabled = true;
                //pictureBox6.Enabled = true;
                //pictureBox7.Enabled = true;
                //pictureBox8.Enabled = true;
                //pictureBox9.Enabled = true;
                //pictureBox10.Enabled = true;
                //pictureBox11.Enabled = true;
                //pictureBox12.Enabled = true;
                //pictureBox13.Enabled = true;
                //pictureBox14.Enabled = true;
                //pictureBox15.Enabled = true;
                //pictureBox16.Enabled = true;

            }
            else
            {
                pictureBox18.Enabled = false;
                pictureBox19.Enabled = false;
                pictureBox20.Enabled = false;
                pictureBox21.Enabled = false;
                pictureBox22.Enabled = false;
                pictureBox23.Enabled = false;
                pictureBox24.Enabled = false;
                pictureBox25.Enabled = false;
                pictureBox26.Enabled = false;
                pictureBox27.Enabled = false;
                pictureBox28.Enabled = false;
                pictureBox29.Enabled = false;
                pictureBox30.Enabled = false;
                pictureBox31.Enabled = false;
                pictureBox32.Enabled = false;
                pictureBox33.Enabled = false;

                //pictureBox1.Enabled = false;
                //pictureBox2.Enabled = false;
                //pictureBox3.Enabled = false;
                //pictureBox4.Enabled = false;
                //pictureBox5.Enabled = false;
                //pictureBox6.Enabled = false;
                //pictureBox7.Enabled = false;
                //pictureBox8.Enabled = false;
                //pictureBox9.Enabled = false;
                //pictureBox10.Enabled = false;
                //pictureBox11.Enabled = false;
                //pictureBox12.Enabled = false;
                //pictureBox13.Enabled = false;
                //pictureBox14.Enabled = false;
                //pictureBox15.Enabled = false;
                //pictureBox16.Enabled = false;
            }
        }

        private void LlenaLista(List<string> cartaslista)
        {
            string cartafuego = @"\Carta_fuego.png";
            string cartamoneda = @"\Carta_moneda.png";
            string cartaojo = @"\Carta_ojo.png";
            string cartatrevol = @"\Carta_trevol.png";
            string cartaglobo = @"\Carta_globo.png";
            string cartaupc = @"\Carta_UPC.png";
            string cartalibro = @"\Carta_libro.png";
            string cartaluna = @"\Carta_luna.png";

            cartaslista.Add(cartafuego);
            cartaslista.Add(cartafuego);

            cartaslista.Add(cartaglobo);
            cartaslista.Add(cartaglobo);

            cartaslista.Add(cartamoneda);
            cartaslista.Add(cartamoneda);

            cartaslista.Add(cartaupc);
            cartaslista.Add(cartaupc);

            cartaslista.Add(cartaojo);
            cartaslista.Add(cartaojo);

            cartaslista.Add(cartalibro);
            cartaslista.Add(cartalibro);

            cartaslista.Add(cartatrevol);
            cartaslista.Add(cartatrevol);

            cartaslista.Add(cartaluna);
            cartaslista.Add(cartaluna);
        }
        public static List<string> DesordenarLista<T>(List<string> input)
        {
            List<string> arr = input;
            List<string> arrDes = new List<string>();

            Random randNum = new Random();
            while (arr.Count > 0)
            {
                int val = randNum.Next(0, arr.Count - 1);
                arrDes.Add(arr[val]);
                arr.RemoveAt(val);
            }
            return arrDes;
        }

        private void LlenarMatriz(List<string> input)
        {
            cartasmatriz = new string[4, 4] { { input[0], input[1], input[2], input[3] }, 
                                              { input[4], input[5], input[6], input[7] }, 
                                              { input[8], input[9], input[10], input[11] }, 
                                              { input[12], input[13], input[14], input[15] } };
        }

        private void LLenaPictureBox(string[,] cartasmatriz)
        {
            pictureBox1.Load(Application.StartupPath + cartasmatriz[0,0]);
            pictureBox2.Load(Application.StartupPath + cartasmatriz[1, 0]);
            pictureBox3.Load(Application.StartupPath + cartasmatriz[2, 0]);
            pictureBox4.Load(Application.StartupPath + cartasmatriz[3, 0]);
            pictureBox5.Load(Application.StartupPath + cartasmatriz[0, 1]);
            pictureBox6.Load(Application.StartupPath + cartasmatriz[1, 1]);
            pictureBox7.Load(Application.StartupPath + cartasmatriz[2, 1]);
            pictureBox8.Load(Application.StartupPath + cartasmatriz[3, 1]);
            pictureBox9.Load(Application.StartupPath + cartasmatriz[0, 2]);
            pictureBox10.Load(Application.StartupPath + cartasmatriz[1, 2]);
            pictureBox11.Load(Application.StartupPath + cartasmatriz[2, 2]);
            pictureBox12.Load(Application.StartupPath + cartasmatriz[3, 2]);
            pictureBox13.Load(Application.StartupPath + cartasmatriz[0, 3]);
            pictureBox14.Load(Application.StartupPath + cartasmatriz[1, 3]);
            pictureBox15.Load(Application.StartupPath + cartasmatriz[2, 3]);
            pictureBox16.Load(Application.StartupPath + cartasmatriz[3, 3]);
        }

        private void StringLista(List<string> input)
        {
            int i = 0;
            string[] valor = new string[16];
            

            while (i < 16)
            {
                if(Convert.ToString(input[i])== "\\Carta_fuego.png")
                {
                    valor[i] = Convert.ToString(0);
                }
                else if (Convert.ToString(input[i]) == "\\Carta_moneda.png")
                {
                    valor[i] = Convert.ToString(1);
                }
                else if (Convert.ToString(input[i]) == "\\Carta_ojo.png")
                {
                    valor[i] = Convert.ToString(2);
                }
                else if (input[i] == "\\Carta_trevol.png")
                {
                    valor[i] = Convert.ToString(3);
                }
                else if (input[i] == "\\Carta_globo.png")
                {
                    valor[i] = Convert.ToString(4);
                }
                else if (input[i] == "\\Carta_UPC.png")
                {
                    valor[i] = Convert.ToString(5);
                }
                else if (input[i] == "\\Carta_libro.png")
                {
                    valor[i] = Convert.ToString(6);
                }
                else if (input[i] == "\\Carta_luna.png")
                {
                    valor[i] = Convert.ToString(7);
                }

                i++;
            }
            ListaEnviada = valor[0] + "-" + valor[1] + "-" + valor[2] + "-" + valor[3] + 
                     "-" + valor[4] + "-" + valor[5] + "-" + valor[6] + "-" + valor[7] + 
                     "-" + valor[8] + "-" + valor[9] + "-" + valor[10] + "-" + valor[11] + 
                     "-" + valor[12] + "-" + valor[13] + "-" + valor[14] + "-" + valor[15];
        }

        private void EnviarLista(string ListaEnviada)
        {
            string mensaje = "10/" + nForm + "/" + Tu + "/" + ListaEnviada + "/" + id;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void IniciarPartida() // Método que se llama para que servidor sepa que se inicia la partida
        {
            string mensaje = "12/" + id;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        public void LlenarConRecibido(string lista)
        {
            string[] recibido = lista.Split('-');
            string[] valor = new string[16];
            int i = 0;
           
            while (i < 16)
            {
                if (Convert.ToInt32(recibido[i]) == 0)
                {
                    valor[i] = "\\Carta_fuego.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 1)
                {
                    valor[i] = "\\Carta_moneda.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 2)
                {
                    valor[i] = "\\Carta_ojo.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 3)
                {
                    valor[i] = "\\Carta_trevol.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 4)
                {
                    valor[i] = "\\Carta_globo.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 5)
                {
                    valor[i] = "\\Carta_UPC.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 6)
                {
                    valor[i] = "\\Carta_libro.png";
                }
                else if (Convert.ToInt32(recibido[i]) == 7)
                {
                    valor[i] = "\\Carta_luna.png";
                }
                i++;
            }
            cartasmatriz = new string[4, 4] { {valor[0], valor[1], valor[2], valor[3] },
                                              {valor[4], valor[5], valor[6], valor[7] },
                                              {valor[8], valor[9], valor[10], valor[11] },
                                              {valor[12], valor[13], valor[14], valor[15] } };

            LLenaPictureBox(cartasmatriz);

        }

     

        private void Form3_Load(object sender, EventArgs e)
        {
            ganador = Tu;
            puntos = 0;
            puntuacionmax = 0;

            timer3.Start();

            pictureBox18.Enabled = false;
            pictureBox19.Enabled = false;
            pictureBox20.Enabled = false;
            pictureBox21.Enabled = false;
            pictureBox22.Enabled = false;
            pictureBox23.Enabled = false;
            pictureBox24.Enabled = false;
            pictureBox25.Enabled = false;
            pictureBox26.Enabled = false;
            pictureBox27.Enabled = false;
            pictureBox28.Enabled = false;
            pictureBox29.Enabled = false;
            pictureBox30.Enabled = false;
            pictureBox31.Enabled = false;
            pictureBox32.Enabled = false;
            pictureBox33.Enabled = false;

            pictureBox1.Enabled = false;
            pictureBox2.Enabled = false;
            pictureBox3.Enabled = false;
            pictureBox4.Enabled = false;
            pictureBox5.Enabled = false;
            pictureBox6.Enabled = false;
            pictureBox7.Enabled = false;
            pictureBox8.Enabled = false;
            pictureBox9.Enabled = false;
            pictureBox10.Enabled = false;
            pictureBox11.Enabled = false;
            pictureBox12.Enabled = false;
            pictureBox13.Enabled = false;
            pictureBox14.Enabled = false;
            pictureBox15.Enabled = false;
            pictureBox16.Enabled = false;

            pictureBox17.Visible = false;

            if (host != Teinvita)
            {
                // Marcamos un tiempo de vida de la invitación
                label5.Text = Convert.ToString(tiempoinvitacion);
                label6.Text = ("Estás jugando como: invitado");
                timer1.Start();

            }
            else
            {
                // Cambios estéticos en el formulario
                botonAceptar.Enabled = false;
                botonAceptar.Visible = false;
                botonRechazar.Enabled = false;
                botonRechazar.Visible = false;

                label4.Enabled = false;
                label4.Visible = false;
                label5.Enabled = false;
                label5.Visible = false;

                pictureBox17.Visible = true;

                label6.Text = ("Estás jugando como: anfitrión");
                timer2.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (tiempoinvitacion == 0)
            {
                timer1.Stop();
                string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0"; // Mensaje de rechazar dado que se ha acabado el tiempo
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                this.Close();
            }
            else
            {
                tiempoinvitacion = tiempoinvitacion - 1;
                label5.Text = Convert.ToString(tiempoinvitacion);
            }
        }

        private void botonAceptar_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/1";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Cambios estéticos en el formulario
            botonAceptar.Enabled = false;
            botonAceptar.Visible = false;
            botonRechazar.Enabled = false;
            botonRechazar.Visible = false;

            label4.Enabled = false;
            label4.Visible = false;
            label5.Enabled = false;
            label5.Visible = false;

            pictureBox17.Visible = true;
        }

        private void botonRechazar_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mensaje = "9/" + nForm + "/" + textBox1.Text + "/" + Tu + "/" + id;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            textBox1.Clear();
        }

 

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (tiempoiniciopartida == 0)
            {
                timer2.Stop();
                label7.Text = "Tus puntos: " + puntos;

                // Pasamos las matrices a todos los jugadores
                cartaslista = new List<string>();
                LlenaLista(cartaslista);
                cartaslista = DesordenarLista<string>(cartaslista);
                LlenarMatriz(cartaslista);
                LLenaPictureBox(cartasmatriz);
                StringLista(cartaslista);
                EnviarLista(ListaEnviada);

                // Se inicia la partida
                IniciarPartida();


            }
            else
            {
                tiempoiniciopartida = tiempoiniciopartida - 1;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (clickcont == 2 && eselturnode == Tu)
            {
                timer3.Stop();
                EnviarJugada(selec1, selec2, pos1, pos2);
                clickcont = 0;
                timer3.Start();
            }
        }


        int contrecibidas = 0;
        int vista1 = 0;
        int vista2 = 0;
        public void RecibirJugada(string pos1, string pos2, int acertado, int puntuacionmax, string ganador)
        {
            this.puntuacionmax = puntuacionmax;
            this.ganador = ganador;

            label9.Text = ganador;
            label12.Text = Convert.ToString(puntuacionmax);

            int carta1 = Convert.ToInt32(pos1);
            int carta2 = Convert.ToInt32(pos2);
            if ((carta1 == 1) || (carta2 == 1))
            {
                pictureBox18.Visible = false;
                if (vista1 == 0)
                {
                    vista1 = 1;
                }
                else
                {
                    vista2 = 1;
                }
                contrecibidas++;
            }
            if ((carta1 == 2) || (carta2 == 2))
            {
                pictureBox19.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 2;
                }
                else
                {
                    vista2 = 2;
                }
            }
            if ((carta1 == 3) || (carta2 == 3))
            {
                pictureBox20.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 3;
                }
                else
                {
                    vista2 = 3;
                }
            }
            if ((carta1 == 4) || (carta2 == 4))
            {
                pictureBox21.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 4;
                }
                else
                {
                    vista2 = 4;
                }
            }
            if ((carta1 == 5) || (carta2 == 5))
            {
                pictureBox22.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 5;
                }
                else
                {
                    vista2 = 5;
                }
            }
            if ((carta1 == 6) || (carta2 == 6))
            {
                pictureBox23.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 6;
                }
                else
                {
                    vista2 = 6;
                }
            }
            if ((carta1 == 7) || (carta2 == 7))
            {
                pictureBox24.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 7;
                }
                else
                {
                    vista2 = 7;
                }
            }
            if ((carta1 == 8) || (carta2 == 8))
            {
                pictureBox25.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 8;
                }
                else
                {
                    vista2 = 8;
                }
            }
            if ((carta1 == 9) || (carta2 == 9))
            {
                pictureBox26.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 9;
                }
                else
                {
                    vista2 = 9;
                }
            }
            if ((carta1 == 10) || (carta2 == 10))
            {
                pictureBox27.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 10;
                }
                else
                {
                    vista2 = 10;
                }
            }
            if ((carta1 == 11) || (carta2 == 11))
            {
                pictureBox28.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 11;
                }
                else
                {
                    vista2 = 11;
                }
            }
            if ((carta1 == 12) || (carta2 == 12))
            {
                pictureBox29.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 12;
                }
                else
                {
                    vista2 = 12;
                }
            }
            if ((carta1 == 13) || (carta2 == 13))
            {
                pictureBox30.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 13;
                }
                else
                {
                    vista2 = 13;
                }
            }
            if ((carta1 == 14) || (carta2 == 14))
            {
                pictureBox31.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 14;
                }
                else
                {
                    vista2 = 14;
                }
            }
            if ((carta1 == 15) || (carta2 == 15))
            {
                pictureBox32.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 15;
                }
                else
                {
                    vista2 = 15;
                }
            }
            if ((carta1 == 16) || (carta2 == 16))
            {
                pictureBox33.Visible = false;
                contrecibidas++;
                if (vista1 == 0)
                {
                    vista1 = 16;
                }
                else
                {
                    vista2 = 16;
                }
            }

            if (acertado == 1)
            {
                parejasacertadas = parejasacertadas + 1;
                //ihoi

                if (parejasacertadas == 8)
                {
                    MessageBox.Show("Fin de la partida, ha ganado " + ganador + " con " + puntuacionmax + " puntos");
                }
            }
            else if (acertado == 0)
            {
                System.Threading.Thread.Sleep(3000);
                TaparCartas(Convert.ToInt32(pos1), Convert.ToInt32(pos2));
            }

        }

        private void EnviarJugada(string carta1, string carta2, string pos1, string pos2)
        {
            if (carta1 == carta2)
            {
                puntos = puntos + 5;
                parejasacertadas = parejasacertadas + 1;
                label7.Text = "Tus puntos: " + puntos;

                if (puntos > puntuacionmax)
                {
                    puntuacionmax = puntos;
                    ganador = Tu;

                    label9.Text = ganador;
                    label12.Text = Convert.ToString(puntuacionmax);
                }

                string mensaje = "11/" + nForm + "/" + Tu + "/" + id  + "/" + pos1 + "/" + pos2 + "/" + "1" + "/" + puntuacionmax + "/" + ganador;
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                sonidoacierto.Play();
                System.Threading.Thread.Sleep(500);
                this.IniciarPartida();

            }
            else
            {
                string mensaje = "11/" + nForm + "/" + Tu + "/" + id + "/" + pos1 + "/" + pos2 + "/" + "0" + "/" + puntuacionmax + "/" + ganador;
                
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                sonidoerror.Play();
                TaparCartas(Convert.ToInt32(pos1), Convert.ToInt32(pos2));
                System.Threading.Thread.Sleep(500);
                this.IniciarPartida();
            }
            
            if (parejasacertadas == 8)
            {
                MessageBox.Show("Fin de la partida, ha ganado " + ganador + " con " + puntuacionmax + " puntos");
            }

        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox18.Visible = false;
                pictureBox1_Click(sender, e);
            }
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox19.Visible = false;
                pictureBox2_Click(sender, e);
            }
        }

        private void pictureBox20_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox20.Visible = false;
                pictureBox3_Click(sender, e);
            }
        }

        private void pictureBox21_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox21.Visible = false;
                pictureBox4_Click(sender, e);
            }
        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox22.Visible = false;
                pictureBox5_Click(sender, e);
            }
        }

        private void pictureBox23_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox23.Visible = false;
                pictureBox6_Click(sender, e);
            }
        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox24.Visible = false;
                pictureBox7_Click(sender, e);
            }
        }

        private void pictureBox25_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox25.Visible = false;
                pictureBox8_Click(sender, e);
            }
        }

        private void pictureBox26_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox26.Visible = false;
                pictureBox9_Click(sender, e);
            }
        }

        private void pictureBox27_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox27.Visible = false;
                pictureBox10_Click(sender, e);
            }
        }

        private void pictureBox28_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox28.Visible = false;
                pictureBox11_Click(sender, e);
            }
        }

        private void pictureBox29_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox29.Visible = false;
                pictureBox12_Click(sender, e);
            }
        }

        private void pictureBox30_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox30.Visible = false;
                pictureBox13_Click(sender, e);
            }
        }

        private void pictureBox31_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox31.Visible = false;
                pictureBox14_Click(sender, e);
            }
        }

        private void pictureBox32_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox32.Visible = false;
                pictureBox15_Click(sender, e);
            }
        }

        private void pictureBox33_Click(object sender, EventArgs e)
        {
            if (clickcont < 2)
            {
                pictureBox33.Visible = false;
                pictureBox16_Click(sender, e);
            }
        }

        string selec1;
        string pos1;
        string selec2;
        string pos2;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[0, 0];
                pos1 = "1";
                clickcont = 1;
            }
            else if(clickcont== 1)
            {
                selec2 = cartasmatriz[0, 0];
                pos2 = "1";
                clickcont = 2;
            }   
           
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[1, 0];
                pos1 = "2";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[1, 0];
                pos2 = "2";
                clickcont = 2;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[2, 0];
                pos1 = "3";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[2, 0];
                pos2 = "3";
                clickcont = 2;
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[3, 0];
                pos1 = "4";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[3, 0];
                pos2 = "4";
                clickcont = 2;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[0, 1];
                pos1 = "5";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[0, 1];
                pos2 = "5";
                clickcont = 2;
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[1, 1];
                pos1 = "6";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[1, 1];
                pos2 = "6";
                clickcont = 2;
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[2, 1];
                pos1 = "7";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[2, 1];
                pos2 = "7";
                clickcont = 2;
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[3, 1];
                pos1 = "8";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[3, 1];
                pos2 = "8";
                clickcont = 2;
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[0, 2];
                pos1 = "9";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[0, 2];
                pos2 = "9";
                clickcont = 2;
            }
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[1, 2];
                pos1 = "10";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[1, 2];
                pos2 = "10";
                clickcont = 2;
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[2, 2];
                pos1 = "11";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[2, 2];
                pos2 = "11";
                clickcont = 2;
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[3, 2];
                pos1 = "12";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[3, 2];
                pos2 = "12";
                clickcont = 2;
            }
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[0, 3];
                pos1 = "13";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[0, 3];
                pos2 = "13";
                clickcont = 2;
            }
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[1, 3];
                pos1 = "14";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[1, 3];
                pos2 = "14";
                clickcont = 2;
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[2, 3];
                pos1 = "15";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[2, 3];
                pos2 = "15";
                clickcont = 2;
            }
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            if (clickcont == 0)
            {
                selec1 = cartasmatriz[3, 3];
                pos1 = "16";
                clickcont = 1;
            }
            else if (clickcont == 1)
            {
                selec2 = cartasmatriz[3, 3];
                pos2 = "16";
                clickcont = 2;
            }
        }

        private void TaparCartas(int vista1, int vista2)
        {
            if ((vista1 == 1) || (vista2 == 1))
            {
                pictureBox18.Visible = true;

            }
            if ((vista1 == 2) || (vista2 == 2))
            {
                pictureBox19.Visible = true;

            }
            if ((vista1 == 3) || (vista2 == 3))
            {
                pictureBox20.Visible = true;

            }
            if ((vista1 == 4) || (vista2 == 4))
            {
                pictureBox21.Visible = true;

            }
            if ((vista1 == 5) || (vista2 == 5))
            {
                pictureBox22.Visible = true;

            }
            if ((vista1 == 6) || (vista2 == 6))
            {
                pictureBox23.Visible = true;

            }
            if ((vista1 == 7) || (vista2 == 7))
            {
                pictureBox24.Visible = true;

            }
            if ((vista1 == 8) || (vista2 == 8))
            {
                pictureBox25.Visible = true;

            }
            if ((vista1 == 9) || (vista2 == 9))
            {
                pictureBox26.Visible = true;

            }
            if ((vista1 == 10) || (vista2 == 10))
            {
                pictureBox27.Visible = true;

            }
            if ((vista1 == 11) || (vista2 == 11))
            {
                pictureBox28.Visible = true;

            }
            if ((vista1 == 12) || (vista2 == 12))
            {
                pictureBox29.Visible = true;

            }
            if ((vista1 == 13) || (vista2 == 13))
            {
                pictureBox30.Visible = true;
            }
            if ((vista1 == 14) || (vista2 == 14))
            {
                pictureBox31.Visible = true;
            }
            if ((vista1 == 15) || (vista2 == 15))
            {
                pictureBox32.Visible = true;

            }
            if ((vista1 == 16) || (vista2 == 16))
            {
                pictureBox33.Visible = true;
            }
        }
        int cont4;
        private void timer4_Tick(object sender, EventArgs e)
        {
            cont4++;
            if ((contrecibidas== 2) && (cont4 == 15))
            {
                timer4.Stop();
                TaparCartas(vista1, vista2);
                cont4 = 0;
                vista1 = 0;
                vista2 = 0;
                contrecibidas = 0;
            }
        }


    }
}
