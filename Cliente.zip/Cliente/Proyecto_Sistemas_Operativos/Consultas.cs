﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Proyecto_Sistemas_Operativos
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y el puerto del servidor al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.0.26");
            IPEndPoint ipep = new IPEndPoint(direc, 9080);


            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectarnos al socket
                label1.ForeColor = Color.Green;
                textBoxConsulta2.ForeColor = Color.Black;
                textBoxConsulta3.ForeColor = Color.Black;

                //Consultamos los jugadores registrados
                string mensaje = "3/" + textBoxConsulta2.Text + "/" + textBox1.Text;
                // Enviamos al servidor el nombre introducido
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                // Recibimos la respuesta por parte del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];

                if (Convert.ToString(mensaje) == Convert.ToString(textBox2.Text))
                {
                    MessageBox.Show("Bienvenido " + textBox1.Text);
                }
                else
                {
                    //Mensaje de desconectar
                    mensaje = "0/";

                    msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // FIN del servicio, nos desconectamos del servidor
                    label1.ForeColor = Color.AliceBlue;
                    textBoxConsulta2.ForeColor = Color.Gray;
                    textBoxConsulta3.ForeColor = Color.Gray;
                    server.Shutdown(SocketShutdown.Both);
                    server.Close();
                    MessageBox.Show("Usuario o contraseña erróneos");
                }


            }
            catch (SocketException ex) // Ha habido un error con la conexion
            {
                MessageBox.Show("ERROR: No se ha podido conectar con el servidor");
                return;
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //Mensaje de desconectar
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // FIN del servicio, nos desconectamos del servidor
            label1.ForeColor = Color.AliceBlue;
            textBoxConsulta2.ForeColor = Color.Gray;
            textBoxConsulta3.ForeColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked) //RadioButton de la máxima puntuación y jugador que la tiene
                {
                    string mensaje = "1/" + textBoxConsulta2.Text + "/" + textBoxConsulta3.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // Recibimos la respuesta por parte del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    MessageBox.Show(mensaje);
                }
                else if (radioButton2.Checked) //RadioButton de la puntuación del jugador 'X'
                {
                    string mensaje = "2/" + textBoxConsulta2.Text + "/" + textBoxConsulta3.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // Recibimos la respuesta por parte del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];

                    MessageBox.Show(mensaje);

                }
                else if (radioButton3.Checked) //RadioButton de la contraseña del jugador 'X'
                {
                    string mensaje = "3/" + textBoxConsulta2.Text + "/" + textBoxConsulta3.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    // Recibimos la respuesta por parte del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];

                    MessageBox.Show(mensaje);
                }
                else
                {
                    MessageBox.Show("Se ha conectado con el servidor pero no hay ninguna solicitud que hacerle");
                }
            }
            catch
            {
                MessageBox.Show("Porfavor autentifícate para poder acceder a las consultas");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y el puerto del servidor al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.0.26");
            IPEndPoint ipep = new IPEndPoint(direc, 9080);


            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectarnos al socket
            }
            catch (SocketException ex) // Ha habido un error con la conexion
            {
                MessageBox.Show("ERROR: No se ha podido conectar con el servidor");
                return;
            }
            string mensaje = "4/" + textBox1.Text + "/" + textBox2.Text;
            // Enviamos al servidor el nombre introducido
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Recibimos la respuesta por parte del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);

            //Mensaje de desconectar
            mensaje = "0/";

            msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // FIN del servicio, nos desconectamos del servidor
            label1.ForeColor = Color.AliceBlue;
            textBoxConsulta2.ForeColor = Color.Gray;
            textBoxConsulta3.ForeColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }
    }
}
