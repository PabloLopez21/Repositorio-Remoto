﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Cliente_Proyecto
{
    public partial class Form2 : Form
    {
        int nForm;
        Socket server;
        string Teinvita;
        int id;
        string Tu;
        public Form2(int nForm, Socket server)
        {
            InitializeComponent();
            this.nForm = nForm;
            this.server = server;
        }

        public void MostrarInvitacion(string mensaje, string usuario)
        {
            string[] nombres = mensaje.Split('-');
            Teinvita = nombres[0];
            id = Convert.ToInt32(nombres[1]);
            Tu = usuario;
            label1.Text = ("Te invita " + nombres[0] + "En la partida con Id: " + nombres[1]);
        }
        
        private void Form2_Load(object sender, EventArgs e)
        {
            label2.Text = nForm.ToString();
        }

        private void botonAceptar_Click(object sender, EventArgs e)
        {
            string mensaje = "8/" + nForm + "/" + Teinvita + "/"+ Tu + "/"+ id + "/1";
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void botonRechazar_Click(object sender, EventArgs e)
        {
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0";
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
    }
}
